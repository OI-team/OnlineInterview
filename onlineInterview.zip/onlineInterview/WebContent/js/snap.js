/**
 *调用完系统函数后，别忘了去anychatevent.js对应的回调函数中做相应处理 
 */
function Snap(){
	alert("snap");
	//TODO
}