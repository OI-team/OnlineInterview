package edu.nju.onlineInterview.common;

public class SessionConstant {

	public static final String ACCOUNT_ID = "accountId";
	public static final String LOGIN_FAIL = "loginFail";
}
