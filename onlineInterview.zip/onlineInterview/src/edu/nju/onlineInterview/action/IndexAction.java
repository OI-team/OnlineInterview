package edu.nju.onlineInterview.action;

/**
 * @author margine
 * @time 2016年1月6日
 * @description 
 * contact ch_margine@163.com
 */
public class IndexAction extends BaseAction{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3013015518520698898L;

	@Override
	public String execute(){
		return SUCCESS;
	}

}
