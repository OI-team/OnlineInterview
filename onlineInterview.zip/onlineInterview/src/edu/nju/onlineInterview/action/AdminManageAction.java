package edu.nju.onlineInterview.action;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import edu.nju.onlineInterview.service.StudentService;
import edu.nju.onlineInterview.vo.StudentBriefInfoVO;

/**
 * @author mzdong E-mail:mzdong163.com
 * @description  Administrator manage the interview information, 
 * 				 including the range of time of every interviewing student.
 * @date 2015��12��8�� ����3:00:32
 * @vesion 1.0
 */
public class AdminManageAction extends BaseAction{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4577595438491286254L;
	
	@Autowired
	private StudentService studentService;
	
	private List<StudentBriefInfoVO> briefInfo = new ArrayList<StudentBriefInfoVO>();
	
	@Override
	public String execute(){
		return SUCCESS;
	}

	public String loadStudentList(){
		return SUCCESS;
	}
}
