package edu.nju.onlineInterview.dao;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import edu.nju.onlineInterview.model.Record;

public class AdminDAO extends BaseDAO<Record> {
	private static final Logger log = LoggerFactory.getLogger(AdminDAO.class);
	
	
}
